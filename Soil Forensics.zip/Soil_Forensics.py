import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error


# ==========================================
# 1. HAVERSINE DISTANCE FUNCTION
# ==========================================
# This math function tracks real-world geometric distance over the Earth's curved surface.
# Accepts four parameters: two pairs of latitude and longitude coordinates.
def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculates the great-circle distance between two points
    on the Earth in kilometers.
    """
    # Converts all input degrees into radians via NumPy which is required for trigonometric operations.
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])

    # Calculates the absolute delta (difference) between the two latitudes and longitudes.
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    # Computes the square of half the chord length between the points using the Haversine trigonometric formula.
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    c = 2 * np.arcsin(np.sqrt(a)) #Calculates the angular distance in radians using the great-circle distance relationship.

    earth_radius_km = 6371.0 # Establishes a constant variable for the mean radius of the Earth in kilometers.
    return c * earth_radius_km # Multiplies the angular distance by the Earth's radius to get the actual ground physical distance in kilometers and returns it.


# ==========================================
# 2. SIMULATED FORENSIC DATABASE
# ==========================================
np.random.seed(42) # This guarantees the script produces the exact same "random" data every time it runs.
num_samples = 200 # Defines a variable establishing that our mock database will contain exactly 200 soil log entries.

# every chemical element and spatial coordinate draws 200 float values uniformly distributed between a specified min and max range.
data = {
    'Oxygen_Pct': np.random.uniform(44.0, 48.0, num_samples),
    'Silicon_Pct': np.random.uniform(25.0, 30.0, num_samples),
    'Aluminum_Pct': np.random.uniform(6.0, 9.0, num_samples),
    'Iron_Pct': np.random.uniform(3.0, 6.0, num_samples),
    'Calcium_Pct': np.random.uniform(1.0, 4.0, num_samples),
    # Target coordinates (e.g., bounding box over a region)
    'Latitude': np.random.uniform(-1.25, -1.35, num_samples),
    'Longitude': np.random.uniform(36.75, 36.85, num_samples)
}

df = pd.DataFrame(data)

# ==========================================
# 3. DATA PREPARATION (FEATURES VS. TARGETS)
# ==========================================

# Extracts the 5 columns holding chemical element percentages and assigns them to X, representing the input Features matrix.
X = df[['Oxygen_Pct', 'Silicon_Pct', 'Aluminum_Pct', 'Iron_Pct', 'Calcium_Pct']]

# Extracts both spatial coordinate columns simultaneously and assigns them to y, representing our joint Multi-Output Targets matrix.
y = df[['Latitude', 'Longitude']]

# Split into Training and Testing sets into training data (80%) and test validation data (20%), locking the shuffling distribution with random_state=42.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale chemical percentages (ratios matter immensely in chemometrics)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ==========================================
# 4. MULTI-OUTPUT MODEL TRAINING
# ==========================================
# Random Forest natively evaluates multi-output errors during tree splits specifying 150 unique decision trees, a maximum depth of 10 levels to prevent overfitting.
forensic_model = RandomForestRegressor(n_estimators=150, max_depth=10, random_state=42)
forensic_model.fit(X_train_scaled, y_train)

# ==========================================
# 5. MODEL EVALUATION
# ==========================================
# Predict on test data
predictions = forensic_model.predict(X_test_scaled)

# Calculate standard Mean Squared Error across both targets Measures the overall statistical coordinate error between actual target coordinates (y_test) and predicted coordinates.
mse = mean_squared_error(y_test, predictions)
print(f"Overall Multi-Output MSE: {mse:.6f}") # Outputs the calculated Mean Squared Error to the console console window, formatted to 6 decimal places.

# Convert test matrices back to calculate physical real-world error
test_lats = y_test['Latitude'].values
test_lons = y_test['Longitude'].values
pred_lats = predictions[:, 0]
pred_lons = predictions[:, 1]

distances = haversine_distance(test_lats, test_lons, pred_lats, pred_lons)
print(f"Average Geographic Prediction Error: {distances.mean():.2f} km\n")


# ==========================================
# 6. INFERENCE: ANALYSIS OF AN UNKNOWN SAMPLE
# ==========================================
def predict_soil_origin(chemical_profile):
    """
    Inputs an unknown profile dictionary, scales it, and executes
    the multi-output prediction.
    """
    profile_df = pd.DataFrame([chemical_profile])
    scaled_profile = scaler.transform(profile_df)

    # Predict multi-output target vector
    predicted_vector = forensic_model.predict(scaled_profile)[0]

    return {
        "Predicted Latitude": predicted_vector[0],
        "Predicted Longitude": predicted_vector[1]
    }


# Simulating an evidence sample found at a crime scene
unknown_evidence = {
    'Oxygen_Pct': 45.2,
    'Silicon_Pct': 27.8,
    'Aluminum_Pct': 7.1,
    'Iron_Pct': 4.3,
    'Calcium_Pct': 2.1
}

result = predict_soil_origin(unknown_evidence)

print("--- Forensic Mapping Results ---")
print(f"Input Chemical Profile: {unknown_evidence}")
print(f"Predicted Geographic Coordinates: {result['Predicted Latitude']:.5f}, {result['Predicted Longitude']:.5f}")