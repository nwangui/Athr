import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor

# Set up page configuration
st.set_page_config(
    page_title="Soil Forensics AI Database Engine",
    page_icon="🌍",
    layout="wide"
)


# ==========================================
# 1. CACHED DATA & MODEL INITIALIZATION
# ==========================================
@st.cache_data
def load_and_train_model():
    """
    Simulates loading the reference database and training the Multi-Output model.
    """
    np.random.seed(42)
    num_samples = 500

    # Simulating UAE-based regional geological clusters
    data = {
        'Silicon_Pct': np.random.uniform(21.0, 30.0, num_samples),
        'Iron_Pct': np.random.uniform(2.5, 9.0, num_samples),
        'Copper_Pct': np.random.uniform(0.01, 0.06, num_samples),
        'Cobalt_Pct': np.random.uniform(0.001, 0.02, num_samples),
        # Target coordinates roughly spanning across the UAE matrix
        'Latitude': np.random.uniform(23.5, 25.8, num_samples),
        'Longitude': np.random.uniform(53.5, 56.3, num_samples)
    }
    df = pd.DataFrame(data)

    feature_cols = ['Silicon_Pct', 'Iron_Pct', 'Copper_Pct', 'Cobalt_Pct']
    X = df[feature_cols]
    y = df[['Latitude', 'Longitude']]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_scaled, y)

    return model, scaler, df, feature_cols


# Load backend assets, reference database, and feature schemas
model, scaler, reference_db, feature_names = load_and_train_model()

# ==========================================
# 2. STREAMLIT USER INTERFACE UI
# ==========================================

# Styled Blue Box Container for Title and Tool Description
# TO THIS:
st.html("""
    <div style="background-color: #E8F1F5; border-left: 6px solid #2B4C5F; padding: 20px; border-radius: 6px; margin-bottom: 25px; font-family: sans-serif;">
        <h1 style="color: #2B4C5F; margin-top: 0;">🌍 Soil Forensics AI Mapping & Analysis Engine</h1>
        <p style="color: #1A303B; font-size: 16px; margin-bottom: 0; line-height: 1.5;">
            This is an artificial intelligence classification tool that takes the chemical profiling metrics of an unknown soil sample and references it 
            against the soil forensic database to determine its location origin or compute its approximate coordinate landscape.
        </p>
    </div>
""")

# Create two-column layout: Left for inputs, Right for mapping/results
col1, col2 = st.columns([1, 2])

with col1:
    st.header("🔬 Forensic Chemical Profiling Input")
    st.markdown("Enter the precise elemental mass analysis percentages derived from XRF/ICP-MS processing:")

    # Using explicit input forms for forensic precision typing
    with st.form("forensic_profile_form"):
        si_pct = st.number_input("Silicon (Si %)", min_value=0.0, max_value=100.0, value=25.0, step=0.1, format="%.2f")
        fe_pct = st.number_input("Iron (Fe %)", min_value=0.0, max_value=100.0, value=4.5, step=0.1, format="%.2f")
        cu_pct = st.number_input("Copper (Cu %)", min_value=0.0, max_value=100.0, value=0.025, step=0.001,
                                 format="%.4f")
        co_pct = st.number_input("Cobalt (Co %)", min_value=0.0, max_value=100.0, value=0.005, step=0.001,
                                 format="%.4f")

        submit_button = st.form_submit_button(label="Analyze & Match Sample")

    # Package sample payload
    unknown_evidence = {
        'Silicon_Pct': si_pct,
        'Iron_Pct': fe_pct,
        'Copper_Pct': cu_pct,
        'Cobalt_Pct': co_pct
    }

with col2:
    st.header("📍 Origin Mapping Resolution")

    # ---- MATCHING & APPROXIMATION LOGIC ----
    tolerance = 1e-3
    exact_matches = reference_db[
        (np.abs(reference_db['Silicon_Pct'] - si_pct) < tolerance) &
        (np.abs(reference_db['Iron_Pct'] - fe_pct) < tolerance) &
        (np.abs(reference_db['Copper_Pct'] - cu_pct) < tolerance) &
        (np.abs(reference_db['Cobalt_Pct'] - co_pct) < tolerance)
        ]

    is_exact = not exact_matches.empty

    if is_exact:
        match_status = "EXACT MATCH IDENTIFIED"
        confidence_level = "CRITICAL / EXACT"
        st.success(f"🎯 {match_status}")
        pred_lat = exact_matches.iloc[0]['Latitude']
        pred_lon = exact_matches.iloc[0]['Longitude']
    else:
        match_status = "APPROXIMATE LOCATION (AI PREDICTIVE REGRESSION)"
        confidence_level = "PROBABLE / APPROXIMATE"
        st.warning(f"⚠️ {match_status}")

        # Execute Model Inference
        input_df = pd.DataFrame([unknown_evidence])
        input_scaled = scaler.transform(input_df)
        prediction = model.predict(input_scaled)[0]

        pred_lat = prediction[0]
        pred_lon = prediction[1]

    # Display coordinate metrics
    m_col1, m_col2 = st.columns(2)
    m_col1.metric(label="Resolved Latitude", value=f"{pred_lat:.5f}°")
    m_col2.metric(label="Resolved Longitude", value=f"{pred_lon:.5f}°")

    # Constructing map layer
    map_data = pd.DataFrame({
        'lat': [pred_lat],
        'lon': [pred_lon]
    })

    # Display dynamic map
    st.markdown("### Geographical Location Plot")
    st.map(map_data, zoom=8)

    # ---- REVISED SECTION A: Technical Forensic Explanation + Integrated Data Payload ----
    st.subheader("🔬 Geological Similarity Analysis")

    # Calculate feature importances to show which element drove the prediction
    importances = model.feature_importances_
    dominant_feature_idx = np.argmax(importances)
    dominant_feature = feature_names[dominant_feature_idx].replace('_Pct', '')

    explanation_text = f"""
    > **Forensic Diagnostic Summary:** The coordinates **{pred_lat:.4f}°, {pred_lon:.4f}°** were determined to be the optimal geographical origin because of the strong multidimensional similarity between this sample's chemical matrix and the baseline records of that specific region.
    The tool evaluated the ratios of all input elements. In this specific analysis, **{dominant_feature}** ratios exerted the highest statistical weight ({importances[dominant_feature_idx] * 100:.1f}% influence) in clustering this sample within its geographic boundary.
    """

    if is_exact:
        explanation_text += f"\n> **Confidence Level:** **{confidence_level}**. This elemental signature exactly mirrors a documented coordinate baseline point in the database, meaning the mineral signature matches the target area with near-zero deviation."
    else:
        explanation_text += f"\n> **Confidence Level:** **{confidence_level}**. While an identical profile was not logged in the static database, the spatial regression system placed the coordinates here due to continuous chemical gradients (such as matching high iron concentrations common in interior mountainous terrains vs. silica trends along coastal corridors)."

    st.markdown(explanation_text)


    # ---- SECTION B: NON-TECHNICAL SUMMARY FOR COURT ----
    with st.expander("⚖️ Legal & Courtroom Expert Testimony Report"):
        st.markdown(f"""
        ### ⚖️ FORENSIC SCIENCE REPORT: GEOGRAPHICAL SOURCE EVALUATION
        **Presented as Non-Technical Expert Evidence**

        ---

        #### 1. Executive Summary
        This report details the scientific process used to determine the geographic origin of a soil sample recovered from physical evidence. Soil is not uniform; it contains a distinct chemical signature derived from local rocks, dust, and human activity. 

        **Tested Evidence Sample Profile Parameters:**
        * 🧪 **Silicon (Si):** {si_pct:.2f} %
        * 🧪 **Iron (Fe):** {fe_pct:.2f} %
        * 🧪 **Copper (Cu):** {cu_pct:.4f} %
        * 🧪 **Cobalt (Co):** {co_pct:.4f} %
        
        By measuring these precise percentages, an artificial intelligence system cross-referenced the sample against a baseline database of known locations across the UAE. The system successfully resolved the sample's geographic origin by identifying the unique mineral "fingerprint" of the terrain.
        
        #### 2. How the Science Works (The "Soil Fingerprint")
        Just as human DNA or toolmarks can isolate a suspect, the ratios of naturally occurring minerals isolate a landscape. The four elements analyzed represent a chemical signature that varies predictably across different environments:
        * **Silicon (Si):** The dominant building block of sand. Highly concentrated in open deserts and coastlines, but low in mountains. Establishes the broad environmental terrain type.
        * **Iron (Fe):** A mineral that gives earth its color. Heavy rocks in mountain ranges break down into highly iron-rich soil. Draws a sharp distinction between flat coastal plains and mountainous regions.
        * **Copper (Cu):** A trace element found naturally in mountain bedrock, but artificially elevated in cities due to vehicle wear and industry. Separates undisturbed environments from populated urban zones.
        * **Cobalt (Co):** A microscopic heavy metal found only in specific deep-earth rock formations. Acts as a geographic "tie-breaker" to pinpoint a specific valley or sub-region.

        #### 3. Analytical System Resolution
        The underlying computer system uses an established branch of forensics known as **Chemometrics** (using chemistry data to categorize samples). 

        * **System Status Flag:** `{match_status}`
        * **Determined Confidence Rating:** `{confidence_level}`

        **Conclusion Interpretation:** The visual interface translates these multi-layered chemical calculations into a single, definitive coordinate plot on an interactive map at **{pred_lat:.5f}°, {pred_lon:.5f}°**. 

        Based on the continuous flow of mineral traits (such as shifting from high-silicon sand to high-iron mountain soil), the system establishes that the evidence sample strongly matches the environmental profile of the designated zone. This provides a reliable, data-driven link connecting physical evidence directly to a specific geographic theater.
        """)